//----------------------------------------------------------------------
//	main.cpp - Gile[s] Lightmapper My3D Exporter to Irrlicht Engine
//	(based on source code of Ogre exporter by Walaber)
//
//	This tool was created by Zhuck Dmitry (ZDimitor).
//	Everyone can use it as wants ( i'll be happy if it helps to someone :) ).
//----------------------------------------------------------------------

#include <windows.h>
#include <stdio.h>
#include <vector>
#include <direct.h>

#include "giles-constants.h"
#include "giles-mem-export.h"
#include "walaber-basic-container.h"

#include "main.h"

//**********************************************************************
//                      some usefull functions
//**********************************************************************
#include "../my3d_common/somefuncs.hpp"

using namespace irr;
using namespace core;

//----------------------------------------------------------------------
void LoadPluginData( char* buffer, int& i, int ketsu );
void LoadTextureData( char* buffer, int& i, int ketsu );
Giles::Texture LoadSingleTextureData( char* buffer, int& i, int ketsu );
void LoadMaterialData( char* buffer, int& i, int ketsu );
Giles::Material LoadSingleMaterialData( char* buffer, int& i, int ketsu );
void LoadModelData( char* buffer, int& i, int ketsu );
void LoadSingleModelData( char* buffer, int& i, int ketsu );
void LoadMeshData( char* buffer, int& i, int ketsu );
void VerticeContainerCheck( int numverts );
void FacesContainerCheck( int numfaces );
void CheckBoundingBox( Giles::Vector3& vec );
void ExportMy3DMesh(void);

//----------------------------------------------------------------------
// GLOBALS
FILE* t_file = NULL;
int chunk, size;

Giles::Header header;
Walaber::Container<Giles::Texture> textures;
Walaber::Container<Giles::Material> materials;

Walaber::Container<Giles::Vertex> vertices;
Walaber::Container<Giles::Face> faces;

Giles::Vector3 mesh_min, mesh_max;
float max_radius;

long vert_off = 0;
long face_off = 0;

//----------------------------------------------------------------------
//		 Gile[s] Plugin entry point
//----------------------------------------------------------------------
BOOL APIENTRY DllMain( 
	HANDLE hModule,
    DWORD  ulReasonForCall,
    LPVOID lpReserved 
	)
{
   switch( ulReasonForCall )
   {
   case DLL_PROCESS_ATTACH:
      // Allocate memory here, if you need.
      break;
   case DLL_THREAD_ATTACH:
   case DLL_THREAD_DETACH:
      // Not used.
      break;
   case DLL_PROCESS_DETACH:
      // Clean-up allocated memory here.
      break;
   }

   return TRUE;
}
//----------------------------------------------------------------------
// return the type of plugin, and any requests it has for data from Gile[s]. 
EXPORT int EXPORTCALL PluginClass( 
	char* inbuffer, int insize, char* outbuffer, int outsize 
	)
{
	// first write the type of plugin we have.
	outbuffer[0] = Giles::PLUGIN_CLASS_EXPORT;

	// next make requests for data from Gile[s].
	outbuffer[4] = Giles::PLUGIN_DATAREQUEST_GLOBAL;

	return 1;
}
//----------------------------------------------------------------------
// write a string to the *outbuffer with the display the name of the plugin 
// in Gile[s]. This function should return a non-zero value, to indicate success.
EXPORT int EXPORTCALL PluginName( 
	char* inbuffer, int insize, char* outbuffer, int outsize 
	)
{
	sprintf( outbuffer, "My3D exporter" );

	return 1;
}
//----------------------------------------------------------------------
// write a string to the *outbuffer with the file format extension of the plugin. 
// This function should return a non-zero value to indicate success 
EXPORT int EXPORTCALL PluginExtension( 
	char* inbuffer, int insize, char* outbuffer, int outsize 
	)
{
	sprintf( outbuffer, ".my3d" );

	return 1;
}
//----------------------------------------------------------------------
// receive data, and we should use this data to write to the export file.
EXPORT int EXPORTCALL PluginExport( 
	char* inbuffer, int insize, char* outbuffer, int outsize 
	)
{
	_mkdir("Lightmaps");
	int cnt=0;
	FILE *out =0;

	vert_off = 0;
	face_off = 0;

	textures.clear();
	materials.clear();
	vertices.clear();
	faces.clear();
	
	t_file = fopen("debug.txt","wt");
	int i = 0, total = 0;

	mesh_min = Giles::Vector3(0,0,0);
	mesh_max = Giles::Vector3(0,0,0);

	fprintf( t_file, "---------------------------\n");
	fprintf( t_file, "   MY3D EXPORTER DEBUG\n");
	fprintf( t_file, "---------------------------\n");
	fprintf( t_file, "\n");
	fprintf( t_file, "EXPORT STARTED!");

	fprintf( t_file, "INSIZE: %d\n\n", insize );

	// this is the main chunk reader that gets the data from Gile[s]
	// by calling recursive functions.
	chunk = Giles::GetInt( inbuffer, i );
	size  = Giles::GetInt( inbuffer, i );

	// ----------------------------------------------------------
	//		READ 3D DATA MESH FROM HERE
	// ----------------------------------------------------------

	if (chunk==Giles::PLUGIN_DATA)
	{
		// plugin data is correct, start loading!
		total = i + size;
		fprintf( t_file, "PLUGIN_DATA FOUND!  ketsu = %d\n",total);
		LoadPluginData( inbuffer, i, total );
	}
	else
	{
		// something wrong with the data!
		fprintf( t_file, "PLUGIN_DATA chunk not found!" );
	}

	fprintf( t_file, "\n\nTHAT SHOULD BE IT!!!!\n" );
	fprintf( t_file, "i: %d",i);
		
	// this just prints out all of the data found for debugging purposes...
	fprintf( t_file, "\n\nVERTEX DATA AS FOUND FROM GILES:\n");

	for (i=0;i<vertices.count;i++)
	{
		fprintf( t_file, "\tVertex %d\tpos[x]%f [y]%f [z]%f\n", i, vertices.Array[i].pos[0], vertices.Array[i].pos[1], vertices.Array[i].pos[2] );
		fprintf( t_file, "\t\t\tnrm[x]%f [y]%f [z]%f\n", vertices.Array[i].norm[0], vertices.Array[i].norm[1], vertices.Array[i].norm[2] );
		fprintf( t_file, "\t\t\tuv0[u]%f [v]%f\n", vertices.Array[i].uv_0[0], vertices.Array[i].uv_0[1] );
		fprintf( t_file, "\t\t\tuv1[u]%f [v]%f\n", vertices.Array[i].uv_1[0], vertices.Array[i].uv_1[1] );
		fprintf( t_file, "\t\t\tcol[r]%f [g]%f [b]%f [a]%f\n\n", vertices.Array[i].col[0], vertices.Array[i].col[1], vertices.Array[i].col[2], vertices.Array[i].col[3] );
	}

	fprintf( t_file, "\n\n\nINDEX DATA AS FOUND FROM GILES:\n" );

	for (i=0;i<faces.count;i++)
	{
		fprintf( t_file, "\tFace %d\tverts [1]%d [2]%d [3]%d [mat]%d\n", i, faces.Array[i].verts[0], faces.Array[i].verts[1], faces.Array[i].verts[2], faces.Array[i].mat );
	}

	// ----------------------------------------------------------
	//		EXPORT THE MY3D MESH FROM HERE
	// ----------------------------------------------------------

	fprintf( t_file, "\n\n\n");
	fprintf( t_file, "EXPORTING MESH...\n" );
	ExportMy3DMesh();
	fprintf( t_file, "MESH EXPORTED!!\n" );

	//close the debug file.
	fclose( t_file );
	t_file = NULL;

	MessageBox(NULL, "Don't forget to copy your lightmaps into 'Lightmaps' directory","Warning!", MB_OK);

	textures.clear();
	materials.clear();
	vertices.clear();
	faces.clear();

	return 1;
}

//----------------------------------------------------------------------
void LoadPluginData( char* buffer, int& i, int ketsu )
{
	std::string test;
	int ketsu2;
	
	while (i < ketsu)
	{
		chunk = Giles::GetInt( buffer, i );
		size = Giles::GetInt( buffer, i );

		switch (chunk)
		{
		// HEADER PORTION
		case Giles::PLUGIN_VERSION:
			//plugin version float.
			header.plugin_version = Giles::GetFloat( buffer, i);
			fprintf(t_file, "PLUGIN_VERSION: %f\n", header.plugin_version );
			break;

		case Giles::PLUGIN_EXPORTFILE:
			//plugin exportfile!
			header.exportfile = Giles::GetString( buffer, i, size );
			fprintf( t_file, "PLUGIN_EXPORTFILE: %s\n", header.exportfile.c_str() );
			break;

		case Giles::PLUGIN_SCENEPATH:
			// plugin scene path!
			header.scenepath = Giles::GetString( buffer, i, size );
			fprintf( t_file, "PLUGIN_SCENEPATH: %s\n", header.scenepath.c_str() );
			break;

		case Giles::PLUGIN_GILESVERSION:
			// giles version
			header.gilesversion = Giles::GetString( buffer, i, size );
			fprintf( t_file, "PLUGIN_GILESVERSION: %s\n", header.gilesversion.c_str() );
			break;			
			
		// MAJOR BLOCKS
		case Giles::PLUGIN_TEXTURES:
			//textures block!
			//for now, just increate i to next block.
			fprintf( t_file, "TEXTURE BLOCK!\n" );
			ketsu2 = i + size;
			LoadTextureData( buffer, i, ketsu2 );
			break;
			
		case Giles::PLUGIN_MATERIALS:
            //materials block!
			fprintf( t_file, "MATERIALS BLOCK!\n" );
			ketsu2 = i + size;
			LoadMaterialData( buffer, i, ketsu2 );
			break;

		case Giles::PLUGIN_MODELS:
			// models block!
			fprintf( t_file, "MODELS BLOCK!\n" );
			ketsu2 = i + size;
			LoadModelData( buffer, i, ketsu2 );
			break;
		
		default:
			//increate i
			fprintf( t_file, "UNRECOGNIZED CHUNK: %X, SIZE: %d\n",chunk, size);
			i += size;
			break;
		}
	}
}
//----------------------------------------------------------------------
void LoadTextureData( char* buffer, int& i, int ketsu )
{
	int ketsu2;
	Giles::Texture temptex;

	int texind =0;

	while (i < ketsu)
	{
		chunk = Giles::GetInt( buffer, i );
		size = Giles::GetInt( buffer, i );

		switch (chunk)
		{
		case Giles::PLUGIN_TEX:
			// this is a texture!
			fprintf( t_file, "PLUGIN_TEX (TEXIND: %d)...\n", texind++);
			ketsu2 = i + size;
			temptex = LoadSingleTextureData( buffer, i, ketsu2 );
			temptex.index = texind;
			textures.add( temptex );

			break;

		default:
			//increate i
			fprintf( t_file, "UNRECOGNIZED CHUNK: %X, SIZE: %d\n",chunk, size);
			i += size;
			break;
		}


	}
}
//----------------------------------------------------------------------
Giles::Texture LoadSingleTextureData( char* buffer, int& i, int ketsu )
{
	Giles::Texture tex;

	while (i < ketsu)
	{
		chunk = Giles::GetInt( buffer, i );
		size = Giles::GetInt( buffer, i );

		switch (chunk)
		{
		case Giles::PLUGIN_TEX_FILE:
			//plugin texture filename!
			tex.filename = Giles::GetString( buffer, i, size );
			fprintf( t_file, "\tPLUGIN_TEX_FILE: %s\n",tex.filename.c_str());
			break;

		case Giles::PLUGIN_TEX_SCALEU:
			//plugin texture scale!
			tex.scaleu = Giles::GetFloat( buffer, i );
			fprintf( t_file, "\tPLUGIN_TEX_SCALEU: %f\n", tex.scaleu );
			break;

		case Giles::PLUGIN_TEX_SCALEV:
			//plugin texture scale!
			tex.scalev = Giles::GetFloat( buffer, i );
			fprintf( t_file, "\tPLUGIN_TEX_SCALEV: %f\n", tex.scalev );
			break;

		case Giles::PLUGIN_TEX_OFFSETU:
			//plugin texture offset!
			tex.offsetu = Giles::GetFloat( buffer, i );
			fprintf( t_file, "\tPLUGIN_TEX_OFFSETU: %f\n", tex.offsetu );
			break;

		case Giles::PLUGIN_TEX_OFFSETV:
			//plugin texture offset!
			tex.offsetv = Giles::GetFloat( buffer, i );
			fprintf( t_file, "\tPLUGIN_TEX_OFFSETV: %f\n", tex.offsetv );
			break;

		case Giles::PLUGIN_TEX_ANGLE:
			//plugin texture rotation angle!
			tex.angle = Giles::GetFloat( buffer, i );
			fprintf( t_file, "\tPLUGIN_TEX_ANGLE: %f\n", tex.angle );
			break;

		case Giles::PLUGIN_TEX_COORDSET:
			//plugin texture coordset!
			tex.tex_coordset = Giles::GetByte( buffer, i );
			fprintf( t_file, "\tPLUGIN_TEX_COORDSET: %d\n", tex.tex_coordset );
			break;

		case Giles::PLUGIN_TEX_FLAGS:
			//plugin texture flags!
			tex.tex_flags = Giles::GetInt( buffer, i );
			fprintf( t_file, "\tPLUGIN_TEX_FLAGS: %d\n", tex.tex_flags );
			break;

		case Giles::PLUGIN_TEX_BLEND:
			//plugin texture blend!
			tex.tex_blend = Giles::GetInt( buffer, i );
			fprintf( t_file, "\tPLUGIN_TEX_BLEND: %d\n", tex.tex_blend );
			break;

		default:
			//increate i
			fprintf( t_file, "\tUNRECOGNIZED CHUNK: %X, SIZE: %d\n",chunk, size);
			i += size;
			break;
		}


	}

	return tex;
}
//----------------------------------------------------------------------
void LoadMaterialData( char* buffer, int& i, int ketsu )
{
	int ketsu2;
	Giles::Material mat;

	while (i < ketsu)
	{
		chunk = Giles::GetInt( buffer, i );
		size = Giles::GetInt( buffer, i );

		switch (chunk)
		{
		case Giles::PLUGIN_MAT:
			// this is a material!
			fprintf( t_file, "PLUGIN_MAT...\n" );
			ketsu2 = i + size;
			mat = LoadSingleMaterialData( buffer, i, ketsu2 );
			materials.add( mat );
			break;

		default:
			//increate i
			fprintf( t_file, "UNRECOGNIZED CHUNK: %X, SIZE: %d\n",chunk, size);
			i += size;
			break;
		}


	}
}
//----------------------------------------------------------------------
Giles::Material LoadSingleMaterialData( char* buffer, int& i, int ketsu )
{
	Giles::Material mat;
	int j, k;

	while (i < ketsu)
	{
		chunk = Giles::GetInt( buffer, i );
		size = Giles::GetInt( buffer, i );

		switch (chunk)
		{
		case Giles::PLUGIN_MAT_NAME:
			//plugin material name!
			mat.matname = "Gile[s]_" + Giles::GetString( buffer, i, size );
			fprintf( t_file, "\tPLUGIN_MAT_NAME: %s\n",mat.matname.c_str());
			break;

		case Giles::PLUGIN_MAT_RED:
			//plugin material red value!
			mat.color.r = Giles::GetFloat( buffer, i );
			fprintf( t_file, "\tPLUGIN_MAT_RED: %f\n",mat.color.r);
			break;

		case Giles::PLUGIN_MAT_GREEN:
			//plugin material green value!
			mat.color.g = Giles::GetFloat( buffer, i );
			fprintf( t_file, "\tPLUGIN_MAT_GREEN: %f\n",mat.color.g);
			break;

		case Giles::PLUGIN_MAT_BLUE:
			//plugin material blue value!
			mat.color.b = Giles::GetFloat( buffer, i );
			fprintf( t_file, "\tPLUGIN_MAT_BLUE: %f\n",mat.color.b);
			break;

		case Giles::PLUGIN_MAT_ALPHA:
			//plugin material alpha value!
			mat.color.a = Giles::GetFloat( buffer, i );
			fprintf( t_file, "\tPLUGIN_MAT_ALPHA: %f\n",mat.color.a);
			break;

		case Giles::PLUGIN_MAT_SELFILLUMINATION:
			//plugin material self illmination value!
			mat.self_illum = Giles::GetFloat( buffer, i );
			fprintf( t_file, "\tPLUGIN_MAT_SELFILLUMINATION: %f\n",mat.self_illum);
			break;

		case Giles::PLUGIN_MAT_SHININESS:
			//plugin material shininess value!
			mat.shininess = Giles::GetFloat( buffer, i );
			fprintf( t_file, "\tPLUGIN_MAT_SHININESS: %f\n",mat.shininess);
			break;

		case Giles::PLUGIN_MAT_TEXLAYER:
			{
			// material texture layer...
			j = Giles::GetByte( buffer, i );			
			k = Giles::GetInt( buffer, i );
			int texind = k; 
			fprintf( t_file, "\tPLUGIN_MAT_TEXLAYER: LAYER: %d TEXIND: %d\n", j, texind);
			mat.texlayers[j] = &textures.Array[k];
			}
			break;
		case Giles::PLUGIN_MAT_FX:
			//material effects!
			mat.mat_fx = Giles::GetInt( buffer, i );
			fprintf( t_file, "\tPLUGIN_MAT_FX: %d\n", mat.mat_fx );
			break;

		case Giles::PLUGIN_MAT_BLEND:
			//material blend!
			mat.mat_blend = Giles::GetInt( buffer, i );
			fprintf( t_file, "\tPLUGIN_MAT_BLEND: %d\n", mat.mat_blend );
			break;
		default:
			//increate i
			fprintf( t_file, "\tUNRECOGNIZED CHUNK: %X, SIZE: %d\n",chunk, size);
			i += size;
			break;
		}


	}

	return mat;
}
//----------------------------------------------------------------------
void LoadModelData( char* buffer, int& i, int ketsu )
{
	int ketsu2;

	while (i < ketsu)
	{
		chunk = Giles::GetInt( buffer, i );
		size = Giles::GetInt( buffer, i );

		switch (chunk)
		{
		case Giles::PLUGIN_MODEL:
			// this is a model!
			fprintf( t_file, "PLUGIN_MODEL...\n" );
			ketsu2 = i + size;
			LoadSingleModelData( buffer, i, ketsu2 );
			break;

		default:
			//increate i
			fprintf( t_file, "UNRECOGNIZED CHUNK: %X, SIZE: %d\n",chunk, size);
			i += size;
			break;
		}


	}
}
//----------------------------------------------------------------------
void LoadSingleModelData( char* buffer, int& i, int ketsu )
{
	int ketsu2;
	std::string stemp;

	while (i < ketsu)
	{
		chunk = Giles::GetInt( buffer, i );
		size = Giles::GetInt( buffer, i );

		switch (chunk)
		{
		case Giles::PLUGIN_MODEL_NAME:
			//plugin model name!
			stemp = Giles::GetString( buffer, i, size );
			fprintf( t_file, "\tPLUGIN_MODEL_NAME: %s\n",stemp.c_str());
			break;

		case Giles::PLUGIN_MESH:
			//plugin mesh!
			// load the mesh data here!
			fprintf( t_file, "\tPLUGIN_MESH\n " );
			ketsu2 = i + size;
			LoadMeshData( buffer, i, ketsu2 );
			vert_off += vertices.count-vert_off;
			face_off += faces.count-face_off;
			break;

		case Giles::PLUGIN_MODEL:
			//this model is a child of the current model!!
			//recursive function call!
			fprintf( t_file, "\tPLUGIN_MODEL...\n" );
			ketsu2 = i + size;
			LoadSingleModelData( buffer, i, ketsu2 );
			break;

		default:
			//increate i
			fprintf( t_file, "\tUNRECOGNIZED CHUNK: %X, SIZE: %d\n",chunk, size);
			i += size;
			break;
		}
	}
}
//----------------------------------------------------------------------
void LoadMeshData( char* buffer, int& i, int ketsu )
{
	int ketsu2;
	std::string stemp;
	int itemp;
	int numvert;
	int cf;

	while (i < ketsu)
	{
		chunk = Giles::GetInt( buffer, i );
		size = Giles::GetInt( buffer, i );

		switch (chunk)
		{
			
		case Giles::PLUGIN_MESH_VERT_GLOBAL_POSITION:
			{
				//vertex positions!!			
				numvert = (size / (3 * 4));
				fprintf( t_file, "\t\tVERTEX POSITIONS:  numverts: %d\n", numvert);
				VerticeContainerCheck( numvert );

				for (int j=0;j<numvert;j++)
				{
					Giles::Vector3 pos;
					pos = Giles::GetVector3( buffer, i );
					CheckBoundingBox( pos );
					vertices.Array[vert_off+j].setPos( pos );

					fprintf( t_file, "\t\t\tVERTEX %d POSITION [x]%f [y]%f [z]%f\n",j,pos.x, pos.y, pos.z);
				}				
			}
			break;				
			
		case Giles::PLUGIN_MESH_VERT_GLOBAL_NORMAL:
			{
				//vertex normals!!
				numvert = (size / (3 * 4));
				fprintf( t_file, "\t\tVERTEX NORMALS:  numverts: %d\n", numvert);
				VerticeContainerCheck( numvert );
				for (int j=0;j<numvert;j++)
				{
					Giles::Vector3 pos;
					pos = Giles::GetVector3( buffer, i );
					vertices.Array[vert_off+j].setNorm( pos );

					fprintf( t_file, "\t\t\tVERTEX %d NORMAL [x]%f [y]%f [z]%f\n",j,pos.x, pos.y, pos.z);
				}
			}
			break;			
		case Giles::PLUGIN_MESH_VERT_COLOR:
			{
				//vertex colors!!
				numvert = (size / (4 * 4));
				fprintf( t_file, "\t\tVERTEX COLORS:  numverts: %d\n", numvert);
				VerticeContainerCheck( numvert );
				for (int j=0;j<numvert;j++)
				{
					Giles::ColourValue col;
					col = Giles::GetColorValue( buffer, i );
					vertices.Array[vert_off+j].setCol( col );

					fprintf( t_file, "\t\t\tVERTEX %d COLOR [r]%f [g]%f [b]%f [a]%f\n",j,col.r, col.g, col.b, col.a);
				}
			}
			break;			
		case Giles::PLUGIN_MESH_VERT_COORDS_0:
			{
				//vertex texture coords 0!!
				numvert = (size / (2 * 4));
				fprintf( t_file, "\t\tVERTEX COORDS 0:  numverts: %d\n", numvert);
				VerticeContainerCheck( numvert );
				for (int j=0;j<numvert;j++)
				{
					Giles::Vector3 uv;
					uv = Giles::GetVector2( buffer, i );
					vertices.Array[vert_off+j].setUV0( uv );

					fprintf( t_file, "\t\t\tVERTEX %d COORD0 [u]%f [v]%f\n",j,uv.x, uv.y);
				}
			}
			break;
		case Giles::PLUGIN_MESH_VERT_COORDS_1:
			{
				//vertex texture coords 1!!
				numvert = (size / (2 * 4));
				fprintf( t_file, "\t\tVERTEX COORDS 1:  numverts: %d\n", numvert);
				VerticeContainerCheck( numvert );
				for (int j=0;j<numvert;j++)
				{
					Giles::Vector3 uv;
					uv = Giles::GetVector2( buffer, i );
					vertices.Array[vert_off+j].setUV1( uv );

					fprintf( t_file, "\t\t\tVERTEX %d COORD1 [u]%f [v]%f\n",j,uv.x, uv.y);
				}
			}
			break;
		
		case Giles::PLUGIN_MESH_POLY_DATA:	
			{	
				// polygon data.  coming from Giles is always triangles.
				ketsu2 = i+size;
				fprintf( t_file, "\t\tPOLY DATA...\n" );
				FacesContainerCheck( (size / ((4*3)+1)) );
				cf = 0;	

				while (i<ketsu2)
				{
					//first is the number of verts.  should be 3.
					itemp = Giles::GetByte( buffer, i );
					fprintf( t_file, "\t\t\tFACE, %d TRIS: ",itemp );
					for (int j=0;j<itemp && j<3;j++)
					{
						//get the vertex index
						int idx = Giles::GetInt( buffer, i );
						faces.Array[face_off+cf].verts[j] = vert_off + idx;
					
						fprintf( t_file, " [%d]",idx );
					}
					fprintf(t_file, "\n");
					cf++;
				}				
			}
			break;
		case Giles::PLUGIN_MESH_POLY_MATERIAL:
			{			
				// polygon material data... AKA submeshes!
				fprintf( t_file, "\t\tFACE MATERIALS...\n");
				ketsu2 = i+size;
				FacesContainerCheck( size / 4 );
				cf = 0;	
				
				while (i<ketsu2)
				{
					int idx = Giles::GetInt( buffer, i );
					faces.Array[face_off+cf].mat = idx;
					cf++;
	
					fprintf( t_file, "\t\t\tFACE %d MAT: %d  aka material name: %s\n", cf, idx, materials.Array[idx].matname.c_str() );
				}
			}
			break;			

		default:
			//increase i
			fprintf( t_file, "\t\tUNRECOGNIZED CHUNK: %X, SIZE: %d\n",chunk, size);
			i += size;
			break;
		}
	}
}
//----------------------------------------------------------------------
void VerticeContainerCheck( int numverts )
{
	while (vertices.count < (vert_off+numverts))
	{
		Giles::Vertex temp;
		vertices.add( temp );
	}
}
//----------------------------------------------------------------------
void FacesContainerCheck( int numfaces )
{
	while (faces.count < (face_off+numfaces) )
	{
		Giles::Face temp;
		faces.add( temp );
	}
}
//----------------------------------------------------------------------
void CheckBoundingBox( Giles::Vector3& vec )
{
	// check max
	if (vec.x > mesh_max.x) { mesh_max.x = vec.x; }
	if (vec.y > mesh_max.y) { mesh_max.y = vec.y; }
	if (vec.z > mesh_max.z) { mesh_max.z = vec.z; }

	//check min
	if (vec.x < mesh_min.x) { mesh_min.x = vec.x; }
	if (vec.y < mesh_min.y) { mesh_min.y = vec.y; }
	if (vec.z < mesh_min.z) { mesh_min.z = vec.z; }

	max_radius = mesh_max.squaredLength();
	if (mesh_min.squaredLength() > max_radius) { max_radius = mesh_min.squaredLength(); }
}
//----------------------------------------------------------------------
// My3D	Main Exporter Function
void ExportMy3DMesh(void)
{

	FILE *out = fopen (header.exportfile.c_str(), "wb");

	if (!out) return;

	u16 id;
	std::vector <int> UsedMaterialsIndexes;

	//---------------------------------------------------
	// writing my3d file header
	//---------------------------------------------------

	SMyFileHeader myFileHeader;

	myFileHeader.MyId=MY_ID;
	myFileHeader.Ver =MY_VER;

	fwrite(&myFileHeader, sizeof(SMyFileHeader), 1, out);

	//---------------------------------------------------
	// writing my scene header
	//---------------------------------------------------

    SMySceneHeader sceneHeader;    

	// calculatin mesh count (according to material indexes of faces)

	sceneHeader.MeshCount =0;

	for( int i=0; i<materials.count; i++ )
	{
		// do a quick count of the number of faces that use this material...
		unsigned int facecount = 0;

		for ( int j=0; j<faces.count; j++)
		{
			if (faces.Array[j].mat == i)
			{
				facecount++;
			}
		}

		if (facecount>0) 
		{	
			sceneHeader.MeshCount++;
			UsedMaterialsIndexes.push_back(i);
		}
	}    

    sceneHeader.BackgrColor.R = 0;
    sceneHeader.BackgrColor.G = 0;
    sceneHeader.BackgrColor.B = 0;
    sceneHeader.BackgrColor.A = 0;	

    sceneHeader.AmbientColor.R = 255;
    sceneHeader.AmbientColor.G = 255;
    sceneHeader.AmbientColor.B = 255;
    sceneHeader.AmbientColor.A = 255;

	sceneHeader.MaterialCount = (u32)UsedMaterialsIndexes.size();

    id = MY_SCENE_HEADER_ID;    
	fwrite(&id, sizeof(id), 1, out);

	fwrite(&sceneHeader, sizeof(SMySceneHeader), 1, out);

	//---------------------------------------------------
	// writing materials list
	//---------------------------------------------------

	id = MY_MAT_LIST_ID;

	fwrite(&id, sizeof(id), 1, out);

	for( int umi=0; umi<UsedMaterialsIndexes.size(); umi++ )
	{
		//-----------------------------------------
		// writing material header
		//-----------------------------------------

		id = MY_MAT_HEADER_ID;
		fwrite(&id, sizeof(id), 1, out);

		SMyMaterialHeader materialHeader;

		int m = UsedMaterialsIndexes[umi];

		int   r = (int)materials.Array[m].color.r;
		int   g = (int)materials.Array[m].color.g;
		int   b = (int)materials.Array[m].color.b;
		float a = materials.Array[m].color.a;       		

		if (r<0)    r=0;    else if(r>255)  r=255;
		if (g<0)    g=0;    else if(g>255)  g=255;
		if (b<0)    b=0;    else if(b>255)  b=255;
		if (a<0.0f) a=0.0f; else if(a>1.0f) a=1.0f;

		float t = 1.0f - 1.0f * a;

		materialHeader.AmbientColor  = SMyColor (r, g, b, 255);
		materialHeader.DiffuseColor  = SMyColor (r, g, b, 255);
		materialHeader.EmissiveColor = SMyColor (0, 0, 0, 0);
		materialHeader.SpecularColor = SMyColor (0, 0, 0, 0);

		materialHeader.Index = umi;

		memset(materialHeader.Name, 0, 256);

		if (materials.Array[m].matname.size()<256)
			sprintf (materialHeader.Name, "%s", materials.Array[m].matname.c_str());
        else
        {   for (int i=0 ;i<255; i++)
                materialHeader.Name[i] = materials.Array[m].matname[i];    
            materialHeader.Name[255]=0; // end of string
        }  
		
		materialHeader.Shininess = materials.Array[m].shininess;

		materialHeader.Trasparency = t;		

		// calc material texture count
		std::vector<Giles::Texture*> mat_tex;
		for (int tl=0 ; tl<Giles::maxTexLayers; tl++)
		{
			if ( materials.Array[m].texlayers[tl] != NULL )
			{
				mat_tex.push_back(materials.Array[m].texlayers[tl]);
			}
		}
		materialHeader.TextureCount = mat_tex.size();

		fwrite(&materialHeader, sizeof(SMyMaterialHeader), 1, out);

		//-----------------------------------------
		// writing material textures names
		//-----------------------------------------

		for (int tx=0; tx<mat_tex.size(); tx++)
        {

			id=MY_TEX_FNAME_ID;
			fwrite(&id, sizeof(id), 1, out);	

			char fulltexfname[256];	
			char texfname    [256];	
			
			memset(fulltexfname, 0, 256);
			memset(texfname,     0, 256);

			Giles::Texture* curr_tex = mat_tex[tx];

			if (curr_tex->filename.size()<256)
				sprintf (fulltexfname, "%s", curr_tex->filename.c_str());
			else
			{   for (int i=0 ;i<255; i++)
				    fulltexfname[i] = curr_tex->filename[i];    
				fulltexfname[255]=0; // end of string
			}  

			extractFileName(fulltexfname, texfname, 256);

			fwrite(&texfname, 256, 1, out);
		}
	}

	//-----------------------------------------
	// writing meshes
	//-----------------------------------------

	id = MY_MESH_LIST_ID;
	fwrite(&id, sizeof(id), 1, out);
	
	SMyVertex myVert;
	SMyMeshHeader meshHeader;
	SMyFace myFace;
	SMyTVertex myTVert;
	SMyFace myTFace;

	int  **redir_indices   = new int*[UsedMaterialsIndexes.size()];
	int *vertmat_count     = new int [UsedMaterialsIndexes.size()];

	for(umi=0; umi<UsedMaterialsIndexes.size(); umi++)
	{
		redir_indices[umi] = new int [vertices.count];

		for (int vc=0; vc<vertices.count; vc++)
		{
			redir_indices[umi][vc]=-1;
		}

		vertmat_count[umi]=0;
	}

	for(umi=0; umi<UsedMaterialsIndexes.size(); umi++ )
	{
		int m = UsedMaterialsIndexes[umi];

		for ( int j=0; j<faces.count; j++)
		{			
			if (faces.Array[j].mat == m)
			{
				int vertA_ind = faces.Array[j].verts[0];
				int vertB_ind = faces.Array[j].verts[1];
				int vertC_ind = faces.Array[j].verts[2];

				if (redir_indices[umi][vertA_ind]==-1)
				{
					redir_indices[umi][vertA_ind]=0;
					vertmat_count[umi]++;
				}

				if (redir_indices[umi][vertB_ind]==-1)
				{
					redir_indices[umi][vertB_ind]=0;
					vertmat_count[umi]++;
				}

				if (redir_indices[umi][vertC_ind]==-1)
				{
					redir_indices[umi][vertC_ind]=0;
					vertmat_count[umi]++;
				}
			}
		}

		int vert_ind_count=0;

		for ( j=0; j<vertices.count; j++)
		{			
			if (redir_indices[umi][j]==0)
			{
				redir_indices[umi][j]=vert_ind_count++;
			}	
		}
	}
	
	for(umi=0; umi<UsedMaterialsIndexes.size(); umi++ )
	{
		id = MY_MESH_HEADER_ID;

		fwrite(&id, sizeof(id), 1, out);

		sprintf(meshHeader.Name, "Gile[s] mesh %d",umi);
		meshHeader.MatIndex = umi;
		meshHeader.TChannelCnt =2;

		int m = UsedMaterialsIndexes[umi];

		fwrite(&meshHeader, sizeof(SMyMeshHeader), 1, out);

		id = MY_VERTS_ID;

		fwrite(&id, sizeof(id), 1, out);

		int vertsNum=vertmat_count[umi];

		fwrite(&vertsNum, sizeof(vertsNum), 1, out);

		for (int j=0; j<vertices.count; j++)
		{
			if (redir_indices[umi][j]!=-1)
			{
				myVert.Coord.X  = -vertices.Array[j].pos[0];
				myVert.Coord.Y  = vertices.Array[j].pos[1];
				myVert.Coord.Z  = -vertices.Array[j].pos[2];
				myVert.Color.R  = vertices.Array[j].col[0];
				myVert.Color.G  = vertices.Array[j].col[1];
				myVert.Color.B  = vertices.Array[j].col[2];
				myVert.Color.A  = vertices.Array[j].col[3];
				myVert.Normal.X = vertices.Array[j].norm[0];
				myVert.Normal.Y = vertices.Array[j].norm[1];
				myVert.Normal.Z = vertices.Array[j].norm[2];

				fwrite(&myVert, sizeof(SMyVertex), 1, out);		
			}
		}

		id = MY_FACES_ID;

		fwrite(&id, sizeof(id), 1, out);

		int facesNum=0;
		for (j=0; j<faces.count; j++)
		{			
			if (faces.Array[j].mat == m)
			{
				facesNum++;
			}
		}

		fwrite(&facesNum, sizeof(facesNum), 1, out);

		for (j=0; j<faces.count; j++)
		{			
			if (faces.Array[j].mat == m)
			{
				myFace.A = redir_indices[umi][faces.Array[j].verts[2]];
				myFace.B = redir_indices[umi][faces.Array[j].verts[1]];
				myFace.C = redir_indices[umi][faces.Array[j].verts[0]];

				fwrite(&myFace, sizeof(SMyFace), 1, out);				
			}
		}

		// 0-texture channel

		id = MY_TVERTS_ID;

		fwrite(&id, sizeof(id), 1, out);

		fwrite(&vertsNum, sizeof(vertsNum), 1, out);
		
		for (j=0; j<vertices.count; j++)
		{
			if (redir_indices[umi][j]!=-1)
			{
				myTVert.TCoord.X  = vertices.Array[j].uv_0[0];
				myTVert.TCoord.Y  = vertices.Array[j].uv_0[1];

				fwrite(&myTVert, sizeof(SMyTVertex), 1, out);
			}
		}

		id = MY_TFACES_ID;

		fwrite(&id, sizeof(id), 1, out);

		fwrite(&facesNum, sizeof(facesNum), 1, out);

		for (j=0; j<faces.count; j++)
		{			
			if (faces.Array[j].mat == m)
			{
				myTFace.A = redir_indices[umi][faces.Array[j].verts[2]];
				myTFace.B = redir_indices[umi][faces.Array[j].verts[1]];
				myTFace.C = redir_indices[umi][faces.Array[j].verts[0]];

				fwrite(&myTFace, sizeof(SMyFace), 1, out);	
			}
		}

		// 1-texture channel

		id = MY_TVERTS_ID;

		fwrite(&id, sizeof(id), 1, out);

		fwrite(&vertsNum, sizeof(vertsNum), 1, out);
		
		for (j=0; j<vertices.count; j++)
		{
			if (redir_indices[umi][j]!=-1)
			{
				myTVert.TCoord.X  = vertices.Array[j].uv_1[0];
				myTVert.TCoord.Y  = vertices.Array[j].uv_1[1];

				fwrite(&myTVert, sizeof(SMyTVertex), 1, out);
			}
		}

		id = MY_TFACES_ID;

		fwrite(&id, sizeof(id), 1, out);

		fwrite(&facesNum, sizeof(facesNum), 1, out);

		for (j=0; j<faces.count; j++)
		{			
			if (faces.Array[j].mat == m)
			{
				myTFace.A = redir_indices[umi][faces.Array[j].verts[2]];
				myTFace.B = redir_indices[umi][faces.Array[j].verts[1]];
				myTFace.C = redir_indices[umi][faces.Array[j].verts[0]];

				fwrite(&myTFace, sizeof(SMyFace), 1, out);	
			}
		}
	} 	

	for(umi=0; umi<UsedMaterialsIndexes.size(); umi++)
	{
		delete redir_indices[umi];
	}

	delete []redir_indices;
	delete []vertmat_count;

	//-----------------------------------------
	// writing end of my3d file
	//-----------------------------------------
	id = MY_FILE_END_ID;

	fwrite(&id, sizeof(id), 1, out);	

	fclose(out);	
}
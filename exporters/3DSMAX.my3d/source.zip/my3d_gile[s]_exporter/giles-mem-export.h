//----------------------------------------------------------------------
//	giles-mem-export.h - Gile[s] Lightmapper My3D Exporter to Irrlicht Engine
//	(based on source code of Ogre exporter by Walaber)
//
//	This tool was created by Zhuck Dmitry (ZDimitor).
//	Everyone can use it as wants ( i'll be happy if it helps to someone :) ).
//----------------------------------------------------------------------

#ifndef _GILES_MEM_EXPORT
#define _GILES_MEM_EXPORT

//-------------------------------------------------------------------

#include <string>

//**********************************************************************
//                      Irrlicht stuff
//***********************************************************************
#include "../my3d_common/irrlicht-stuff.h"

//**********************************************************************
//                      MY3D stuff
//**********************************************************************
#include "../my3d_common/my3d-stuff.h"

//**********************************************************************
//                      Gile[s] stuff
//**********************************************************************

//-------------------------------------------------------------------
namespace Giles {
//-------------------------------------------------------------------
class GilesHeader;
class Texture;
class Material;
struct Vector3;
struct ColourValue;
//-------------------------------------------------------------------
int GetInt( char* buffer, int& i );
int GetByte( char* buffer, int& i );
float GetFloat( char* buffer, int& i );
std::string GetString( char* buffer, int& i, int length );
Vector3 GetVector3( char* buffer, int& i );
ColourValue GetColorValue( char* buffer, int& i );
Vector3 GetVector2( char* buffer, int& i );
void StringRemovePath( std::string& st );
//-------------------------------------------------------------------
// Gile[s] vector 3d
struct Vector3
{
	Vector3() {;}
	Vector3(float _x, float _y, float _z):x(_x), y(_y), z(_z) {;}

	float squaredLength() { return x*x + y*y + z*z; }

	float x, y, z;
};
//-------------------------------------------------------------------
// Gile[s] vertex color
struct ColourValue
{
	float r, g, b, a;
};
//-------------------------------------------------------------------
// CLASS to represent Gile[s] export data header!!
class Header
{
public:
	float plugin_version;
	std::string exportfile;
	std::string scenepath;
	std::string gilesversion;
};	// Header
//-------------------------------------------------------------------
// CLASS to represent Gile[s] single texture element.
class Texture
{
public:
	std::string filename;
	float scaleu, scalev;
	float offsetu, offsetv;
	float angle;
	int tex_flags;
	int tex_blend;
	int tex_coordset;
	int index;

	Texture() : index(-1) {;}
}; // Texture
//-------------------------------------------------------------------
static const int maxTexLayers = 8;
//-------------------------------------------------------------------
// CLASS to represent Gile[s] single material elements.
class Material
{
public:	

	std::string matname;
	ColourValue color;
	float self_illum, shininess;
	int mat_fx, mat_blend;
	Texture* texlayers[maxTexLayers];

	Material();// consructor
};
//-------------------------------------------------------------------
inline Material::Material()
{
	matname = std::string("");
	color = ColourValue();

	self_illum = shininess = 0.0f;
	mat_fx = mat_blend = 0;

	for (int i=0;i<maxTexLayers;i++)
		texlayers[i] = NULL;
}
//-------------------------------------------------------------------
// VERTEX CLASS
class Vertex
{
public:
	float pos[3];
	float norm[3];
	float col[4];
	float uv_0[2];
	float uv_1[2];

	void setPos( Vector3& pos );
	void setNorm( Vector3& norm );
	void setUV0( Vector3& uv );
	void setUV1( Vector3& uv );
	void setCol( ColourValue& col );
};
//-------------------------------------------------------------------
class Face
{
public:
	int verts[3];
	int mat;
};
//-------------------------------------------------------------------
}	// end of namespace Giles
//-------------------------------------------------------------------
#endif	// _GILES_MEM_EXPORT


//----------------------------------------------------------------------
//	walaber-basic-container.h - Gile[s] Lightmapper My3D Exporter to Irrlicht Engine
//	(based on source code of Ogre exporter by Walaber)
//
//	This tool was created by Zhuck Dmitry (ZDimitor).
//	Everyone can use it as wants ( i'll be happy if it helps to someone :) ).
//----------------------------------------------------------------------

#ifndef _WALABER_BASIC_CONTAINER
#define _WALABER_BASIC_CONTAINER

//----------------------------------------------------------------------
namespace Walaber {
//----------------------------------------------------------------------
template<class T>
class Container
{
public:
	int count;
	T* Array;

	Container() { count = 0; Array = NULL; }	// constructor
	~Container() { if (Array) { delete []Array; } }	// destructor

	void add( T& newel );	//add a new material to the array.
	void clear();
};
//----------------------------------------------------------------------
template<class T>
void Container<T>::add( T& newel )
{
	count++;
		
	T* temp = new T[count];

	if (count>0)
	{
		//copy the old stuff into the new array
		for (int i=0;i<count-1;i++)
			temp[i] = Array[i];
	}

	//add the new object
	temp[count-1] = newel;

	// delete the old texture array
	if (Array)
		delete []Array;

	//assign the new one.
	Array = temp;
}
//----------------------------------------------------------------------
template<class T>
void Container<T>::clear()
{	
	if (Array) { delete []Array; } 

	count = 0; Array = NULL;
}
//----------------------------------------------------------------------
}	// end namespace Walaber
//----------------------------------------------------------------------

#endif

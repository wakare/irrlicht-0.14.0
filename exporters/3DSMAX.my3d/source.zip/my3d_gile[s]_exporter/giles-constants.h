//----------------------------------------------------------------------
//	giles-constants.h - Gile[s] Lightmapper My3D Exporter to Irrlicht Engine
//	(based on source code of Ogre exporter by Walaber)
//
//	This tool was created by Zhuck Dmitry (ZDimitor).
//	Everyone can use it as wants ( i'll be happy if it helps to someone :) ).
//----------------------------------------------------------------------

#ifndef _GILES_CONSTANTS
#define _GILES_CONSTANTS

//----------------------------------------------------------------------
namespace Giles{
//----------------------------------------------------------------------
// The plugin class constants
// More than one plugin class may be combined in a single dll!

const int PLUGIN_CLASS_EXPORT  =1;
const int PLUGIN_CLASS_IMPORT  =2;
const int PLUGIN_CLASS_CREATE  =4;
const int PLUGIN_CLASS_MODIFY  =8;

//----------------------------------------------------------------------
// Plugin Data Request flags!
// Each plugin may request to receive data in specific ways by
// passing data request flags back to gile[s] when PluginClass()
// is called.
// Model and vertex data may be received from gile[s] in either
// local or global coordinate space, or both at once.
// If these flags are not sent back to gile[s] it automatically
// sends both local and global data back to the plugin.

const int PLUGIN_DATAREQUEST_LOCAL          =1;
const int PLUGIN_DATAREQUEST_GLOBAL         =2;
const int PLUGIN_DATAREQUEST_NOTEXTURES     =4;
const int PLUGIN_DATAREQUEST_NOMATERIALS    =8;
const int PLUGIN_DATAREQUEST_NOMODELS       =16;
const int PLUGIN_DATAREQUEST_SELECTED       =32;

//----------------------------------------------------------------------
// The chunkIDs
const int PLUGIN_DATA                           =0xFFFF;
const int PLUGIN_VERSION                        =0xFFFE;
const int PLUGIN_EXPORTFILE                     =0xFFFD;
const int PLUGIN_IMPORTFILE                     =0xFFFC;
const int PLUGIN_SCENEPATH                      =0xFFFB;
const int PLUGIN_PLUGINPATH                     =0xFFFA;
const int PLUGIN_SCENEAUTHOR                    =0xFFF9;
const int PLUGIN_GILESVERSION                   =0xFFF8;

const int PLUGIN_TEXTURES                       =0x1000;
const int PLUGIN_TEX                            =0x1001;
const int PLUGIN_TEX_FILE                       =0x1002;
const int PLUGIN_TEX_SCALEU                     =0x1003;
const int PLUGIN_TEX_SCALEV                     =0x1004;
const int PLUGIN_TEX_OFFSETU                    =0x1005;
const int PLUGIN_TEX_OFFSETV                    =0x1006;
const int PLUGIN_TEX_ANGLE                      =0x1007;
const int PLUGIN_TEX_FLAGS                      =0x1008;
const int PLUGIN_TEX_BLEND                      =0x1009;
const int PLUGIN_TEX_COORDSET                   =0x100A;
const int PLUGIN_TEX_MODIFY_ID                  =0x100B;

const int PLUGIN_MATERIALS                      =0x2000;
const int PLUGIN_MAT                            =0x2001;
const int PLUGIN_MAT_NAME                       =0x2002;
const int PLUGIN_MAT_RED                        =0x2003;
const int PLUGIN_MAT_GREEN                      =0x2004;
const int PLUGIN_MAT_BLUE                       =0x2005;
const int PLUGIN_MAT_ALPHA                      =0x2006;
const int PLUGIN_MAT_SELFILLUMINATION           =0x2007;
const int PLUGIN_MAT_SHININESS                  =0x2008;
const int PLUGIN_MAT_FX                         =0x2009;
const int PLUGIN_MAT_BLEND                      =0x200A;
const int PLUGIN_MAT_TEXLAYER                   =0x200B;
const int PLUGIN_MAT_RECEIVEBACK                =0x200C;
const int PLUGIN_MAT_RECEIVESHADOW              =0x200D;
const int PLUGIN_MAT_CASTSHADOW                 =0x200E;
const int PLUGIN_MAT_RECEIVEGI                  =0x200F;
const int PLUGIN_MAT_AFFECTGI                   =0x2010;
const int PLUGIN_MAT_GEOENABLE                  =0x2011;
const int PLUGIN_MAT_GEORANGE                   =0x2012;
const int PLUGIN_MAT_MODIFY_ID                  =0x2013;

const int PLUGIN_MODELS                         =0x3000;
const int PLUGIN_MODEL                          =0x3001;
const int PLUGIN_MODEL_NAME                     =0x3002;
const int PLUGIN_MODEL_LOCAL_POSITION           =0x3003;
const int PLUGIN_MODEL_LOCAL_ROTATION           =0x3004;
const int PLUGIN_MODEL_LOCAL_SCALE              =0x3005;
const int PLUGIN_MODEL_LOCAL_QUATERNION         =0x3006;
const int PLUGIN_MODEL_LOCAL_MATRIX             =0x3007;
const int PLUGIN_MODEL_GLOBAL_POSITION          =0x3008;
const int PLUGIN_MODEL_GLOBAL_ROTATION          =0x3009;
const int PLUGIN_MODEL_GLOBAL_SCALE             =0x300A;
const int PLUGIN_MODEL_GLOBAL_QUATERNION        =0x300B;
const int PLUGIN_MODEL_GLOBAL_MATRIX            =0x300C;
const int PLUGIN_MODEL_CUSTOMPROPS              =0x300D;
const int PLUGIN_MODEL_HIDDEN                   =0x300E;
const int PLUGIN_MODEL_RECEIVEBACK              =0x300F;
const int PLUGIN_MODEL_RECEIVESHADOW            =0x3010;
const int PLUGIN_MODEL_CASTSHADOW               =0x3011;
const int PLUGIN_MODEL_RECEIVEGI                =0x3012;
const int PLUGIN_MODEL_AFFECTGI                 =0x3013;
const int PLUGIN_MODEL_MODIFY_ID                =0x3014;
const int PLUGIN_MODEL_SELECTED                 =0x3015;
const int PLUGIN_MODEL_DELETE                   =0x3016;

const int PLUGIN_MESH                           =0x4000;
const int PLUGIN_MESH_VERT_LOCAL_POSITION       =0x4001;
const int PLUGIN_MESH_VERT_LOCAL_NORMAL         =0x4002;
const int PLUGIN_MESH_VERT_GLOBAL_POSITION      =0x4003;
const int PLUGIN_MESH_VERT_GLOBAL_NORMAL        =0x4004;
const int PLUGIN_MESH_VERT_COLOR                =0x4005;
const int PLUGIN_MESH_VERT_COORDS_0             =0x4006;
const int PLUGIN_MESH_VERT_COORDS_1             =0x4007;
const int PLUGIN_MESH_POLY_DATA                 =0x4008;
const int PLUGIN_MESH_POLY_MATERIAL             =0x4009;
const int PLUGIN_MESH_POLY_SMOOTHGROUP          =0x400A;

const int PLUGIN_PIVOT                          =0x5000;

const int PLUGIN_LIGHT                          =0x6000;
const int PLUGIN_LIGHT_TYPE                     =0x6001;
const int PLUGIN_LIGHT_ACTIVE                   =0x6002;
const int PLUGIN_LIGHT_CASTSHADOWS              =0x6003;
const int PLUGIN_LIGHT_INFINITE                 =0x6004;
const int PLUGIN_LIGHT_OVERSHOOT                =0x6005;
const int PLUGIN_LIGHT_RADIUS                   =0x6006;
const int PLUGIN_LIGHT_RED                      =0x6007;
const int PLUGIN_LIGHT_GREEN                    =0x6008;
const int PLUGIN_LIGHT_BLUE                     =0x6009;
const int PLUGIN_LIGHT_INTENSITY                =0x600A;
const int PLUGIN_LIGHT_NEAR                     =0x600B;
const int PLUGIN_LIGHT_FAR                      =0x600C;
const int PLUGIN_LIGHT_INNER                    =0x600D;
const int PLUGIN_LIGHT_OUTER                    =0x600E;


const int BLEND_ALPHA			= 1;
const int BLEND_MULTIPLY		= 2;
const int BLEND_ADD				= 3;
const int BLEND_DOT3			= 4;
const int BLEND_MODULATE2X		= 5;

const int MAT_FX_FULLBRIGHT			= 1;
const int MAT_FX_VERTEXCOLOR		= 2;
const int MAT_FX_FLATSHADE			= 4;
const int MAT_FX_NOFOG				= 8;
const int MAT_FX_TWOSIDED			= 16;

const int TEX_FLAG_COLOR			= 1;
const int TEX_FLAG_ALPHA			= 2;
const int TEX_FLAG_MASK				= 4;
const int TEX_FLAG_MIPMAP			= 8;
const int TEX_FLAG_CLAMPU			= 16;
const int TEX_FLAG_CLAMPV			= 32;
const int TEX_FLAG_SPHEREMAP		= 64;
const int TEX_FLAG_CUBEMAP			= 128;
const int TEX_FLAG_VRAM				= 256;
const int TEX_FLAG_TRUECOLOR		= 512;

//----------------------------------------------------------------------
}	// end of namespace Giles
//----------------------------------------------------------------------

#endif	// _GILES_CONSTANTS

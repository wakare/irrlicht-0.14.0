//----------------------------------------------------------------------
//	giles-mem-export.cpp - Gile[s] Lightmapper My3D Exporter to Irrlicht Engine
//	(based on source code of Ogre exporter by Walaber)
//
//	This tool was created by Zhuck Dmitry (ZDimitor).
//	Everyone can use it as wants ( i'll be happy if it helps to someone :) ).
//----------------------------------------------------------------------

#include "giles-constants.h"
#include "giles-mem-export.h"

//----------------------------------------------------------------------
namespace Giles
{
//----------------------------------------------------------------------
void Vertex::setPos( Vector3& posit )
{
	pos[0] = posit.x;
	pos[1] = posit.y;
	pos[2] = posit.z;
}
//----------------------------------------------------------------------
void Vertex::setNorm( Vector3& normal )
{
	norm[0] = normal.x;
	norm[1] = normal.y;
	norm[2] = normal.z;
}
//----------------------------------------------------------------------
void Vertex::setUV0( Vector3& uv )
{
	uv_0[0] = uv.x;
	uv_0[1] = uv.y;	
}
//----------------------------------------------------------------------
void Vertex::setUV1( Vector3& uv )
{
	uv_1[0] = uv.x;
	uv_1[1] = uv.y;	
}
//----------------------------------------------------------------------
void Vertex::setCol( ColourValue& color )
{
	col[0] = color.r;
	col[1] = color.g;
	col[2] = color.b;
	col[3] = color.a;
}		
//----------------------------------------------------------------------
int GetInt( char* buffer, int& i )
{
	int ret = (int)(*(long*)(buffer+i)); i+=4;

	return ret;
}
//----------------------------------------------------------------------
int GetByte( char* buffer, int& i )
{
	int ret = (int)(*(char*)(buffer+i)); i+=1;

	return ret;
}
//----------------------------------------------------------------------
float GetFloat( char* buffer, int& i )
{
	float ret = (float)(*(float*)(buffer+i)); i+=4;

	return ret;
}
//----------------------------------------------------------------------
std::string GetString( char* buffer, int& i, int length )
{	
	std::string ret;

	char *ch = new char[length];

	for (int j=0;j<length;j++)
	{
		ch[j] = buffer[i+j];
	}
	
	ret = ch;

	delete []ch;

	i += length;

	return ret;
}
//----------------------------------------------------------------------
Vector3 GetVector3( char* buffer, int& i )
{
	Vector3 ret;

	ret.x = Giles::GetFloat( buffer, i );
	ret.y = Giles::GetFloat( buffer, i );
	ret.z = Giles::GetFloat( buffer, i );

	return ret;
}
//----------------------------------------------------------------------
ColourValue GetColorValue( char* buffer, int& i )
{
	ColourValue ret;

	ret.r = Giles::GetFloat( buffer, i );
	ret.g = Giles::GetFloat( buffer, i );
	ret.b = Giles::GetFloat( buffer, i );
	ret.a = Giles::GetFloat( buffer, i );

	return ret;
}
//----------------------------------------------------------------------
Vector3 GetVector2( char* buffer, int& i )
{
	Vector3 ret;

	ret.x = Giles::GetFloat( buffer, i );
	ret.y = Giles::GetFloat( buffer, i );

	return ret;
}
//----------------------------------------------------------------------
void StringRemovePath( std::string& st )
{

	std::string std = static_cast<std::string>(st);

	size_t last = std.find_last_of( "\\" );

	st = std.substr(last+1);

}
//----------------------------------------------------------------------
}	//	end of namespace giles


//----------------------------------------------------------------------
//	main.h - Gile[s] Lightmapper My3D Exporter to Irrlicht Engine
//	(based on source code of Ogre exporter by Walaber)
//
//	This tool was created by Zhuck Dmitry (ZDimitor).
//	Everyone can use it as wants ( i'll be happy if it helps to someone :) ).
//----------------------------------------------------------------------

#define EXPORT extern "C" __declspec (dllexport)
#define EXPORTCALL _stdcall 

//----------------------------------------------------------------------
//exporting function declarations
//----------------------------------------------------------------------

// return the type of plugin, and any requests it has for data from Gile[s]. 
EXPORT int EXPORTCALL PluginClass( 
	char* inbuffer, int insize, char* outbuffer, int outsize 
	);
// write a string to the *outbuffer with the display the name of the plugin 
// in Gile[s]. This function should return a non-zero value, to indicate success.
EXPORT int EXPORTCALL PluginName( 
	char* inbuffer, int insize, char* outbuffer, int outsize 
	);
// write a string to the *outbuffer with the file format extension of the plugin. 
// This function should return a non-zero value to indicate success 
EXPORT int EXPORTCALL PluginExtension( 
	char* inbuffer, int insize, char* outbuffer, int outsize 
	);
// receive data, and we should use this data to write to the export file.
EXPORT int EXPORTCALL PluginExport( 
	char* inbuffer, int insize, char* outbuffer, int outsize 
	);

//----------------------------------------------------------------------	
//----------------------------------------------------------------------
//  irrlicht-stuff.h - part of the My3D Tools
//
//  This tool was created by Zhuck Dmitry (ZDimitor).
//  Everyone can use it as wants ( i'll be happy if it helps to someone :) ).
//----------------------------------------------------------------------

#ifndef __irlicht_stuff__
#define __irlicht_stuff__

//**********************************************************************
//                      Irrlicht stuff
//***********************************************************************

//----------------------------------------------------------------------------
//! 8 bit unsigned variable.
/** This is a typedef for unsigned char, it ensures portability of the engine. */
typedef unsigned char       u8;
//----------------------------------------------------------------------------
//! 8 bit signed variable.
/** This is a typedef for signed char, it ensures portability of the engine. */
typedef signed char         s8;
//----------------------------------------------------------------------------
//! 8 bit character variable.
/** This is a typedef for char, it ensures portability of the engine. */
typedef char                c8;
//----------------------------------------------------------------------------
//! 16 bit unsigned variable.
/** This is a typedef for unsigned short, it ensures portability of the engine. */
typedef unsigned short      u16;
//----------------------------------------------------------------------------
//! 16 bit signed variable.
/** This is a typedef for signed short, it ensures portability of the engine. */
typedef signed short        s16;
//----------------------------------------------------------------------------
//! 32 bit unsigned variable.
/** This is a typedef for unsigned int, it ensures portability of the engine. */
typedef unsigned int        u32;
//----------------------------------------------------------------------------
//! 32 bit signed variable.
/** This is a typedef for signed int, it ensures portability of the engine. */
typedef signed int          s32;
//----------------------------------------------------------------------------
// 64 bit signed variable.
// This is a typedef for __int64, it ensures portability of the engine.
// This type is currently not used by the engine and not supported by compilers
// other than Microsoft Compilers, so it is outcommented.
typedef __int64               s64;
//----------------------------------------------------------------------------
//! 32 bit floating point variable.
/** This is a typedef for float, it ensures portability of the engine. */
typedef float               f32;
//----------------------------------------------------------------------------
//! 64 bit floating point variable.
/** This is a typedef for double, it ensures portability of the engine. */
typedef double              f64;

//---------------------------------------------------------------------------
//! 3d vector template class with lots of operators and methods.
template <class T>
class vector3d  
{
public:
    //------------------------------------------------------------------------
    // Constructors
    //------------------------------------------------------------------------
    vector3d(): X(0), Y(0), Z(0) {};
    vector3d(T nx, T ny, T nz) : X(nx), Y(ny), Z(nz) {};
    vector3d(const vector3d<T>& other)  :X(other.X), Y(other.Y), Z(other.Z) {};

    //------------------------------------------------------------------------
    // operators
    //------------------------------------------------------------------------
    vector3d<T>& operator=(const vector3d<T>& other)    { X = other.X; Y = other.Y; Z = other.Z; return *this; }

    vector3d<T> operator+(const vector3d<T>& other) const { return vector3d<T>(X + other.X, Y + other.Y, Z + other.Z);  }
    vector3d<T>& operator+=(const vector3d<T>& other)   { X+=other.X; Y+=other.Y; Z+=other.Z; return *this; }

    vector3d<T> operator-(const vector3d<T>& other) const { return vector3d<T>(X - other.X, Y - other.Y, Z - other.Z);  }
    vector3d<T>& operator-=(const vector3d<T>& other)   { X-=other.X; Y-=other.Y; Z-=other.Z; return *this; }

    vector3d<T> operator*(const vector3d<T>& other) const { return vector3d<T>(X * other.X, Y * other.Y, Z * other.Z);  }
    vector3d<T>& operator*=(const vector3d<T>& other)   { X*=other.X; Y*=other.Y; Z*=other.Z; return *this; }
    vector3d<T> operator*(const T v) const { return vector3d<T>(X * v, Y * v, Z * v);   }
    vector3d<T>& operator*=(const T v) { X*=v; Y*=v; Z*=v; return *this; }

    vector3d<T> operator/(const vector3d<T>& other) const { return vector3d<T>(X / other.X, Y / other.Y, Z / other.Z);  }
    vector3d<T>& operator/=(const vector3d<T>& other)   { X/=other.X; Y/=other.Y; Z/=other.Z; return *this; }
    vector3d<T> operator/(const T v) const { T i=(T)1.0/v; return vector3d<T>(X * i, Y * i, Z * i); }
    vector3d<T>& operator/=(const T v) { T i=(T)1.0/v; X*=i; Y*=i; Z*=i; return *this; }

    bool operator<=(const vector3d<T>&other) const { return X<=other.X && Y<=other.Y && Z<=other.Z;};
    bool operator>=(const vector3d<T>&other) const { return X>=other.X && Y>=other.Y && Z>=other.Z;};

    bool operator==(const vector3d<T>& other) const { return other.X==X && other.Y==Y && other.Z==Z; }
    bool operator!=(const vector3d<T>& other) const { return other.X!=X || other.Y!=Y || other.Z!=Z; }

    //------------------------------------------------------------------------
    // functions
    //------------------------------------------------------------------------
    void set(const T nx, const T ny, const T nz) {X=nx; Y=ny; Z=nz; }
    //------------------------------------------------------------------------
    void set(const vector3d<T>& p) { X=p.X; Y=p.Y; Z=p.Z;}
    //------------------------------------------------------------------------
    //! Returns length of the vector.
    f64 getLength() const { return sqrt(X*X + Y*Y + Z*Z); }
    //------------------------------------------------------------------------
    //! Returns squared length of the vector.
    //! This is useful because it is much faster then
    //! getLength().
    f64 getLengthSQ() const { return X*X + Y*Y + Z*Z; }
    //------------------------------------------------------------------------
    //! Returns the dot product with another vector.
    T dotProduct(const vector3d<T>& other) const
    {
        return X*other.X + Y*other.Y + Z*other.Z;
    }
    //------------------------------------------------------------------------
    //! Returns squared distance from an other point. 
    //! Here, the vector is interpreted as point in 3 dimensional space.
    f32 getDistanceFromSQ(const vector3d<T>& other) const
    {
        f32 vx = X - other.X; f32 vy = Y - other.Y; f32 vz = Z - other.Z;
        return (vx*vx + vy*vy + vz*vz);
    }
    //------------------------------------------------------------------------
    vector3d<T> crossProduct(const vector3d<T>& p) const
    {
        return vector3d<T>(Y * p.Z - Z * p.Y, Z * p.X - X * p.Z, X * p.Y - Y * p.X);
    }
    //------------------------------------------------------------------------
    //! Normalizes the vector.
    vector3d<T>& normalize()
    {   T len = (T)getLength();

        //������ �� ������� �� ���� (���� �� ���� :) )
        if (len==0) len+=(T)0.000001;

        T inv = (T)1.0 / len;
        X *= inv;
        Y *= inv;
        Z *= inv; 
        return *this;
    }
    //------------------------------------------------------------------------
    //! ��������� ���� ����� ����� ��������� (����)
    f64 getAngleDeg(const vector3d<T>& other)
    {   f64 div  = getLength()*other.getLength();
        f64 _cos = (dotProduct(other))/(div!=0?div:0.000001);
        f64 rad  = acos(_cos);
        f64 deg  = rad*(f64)GRAD_PI;
        return deg;
    }
    //------------------------------------------------------------------------
    //! ��������� ���� ����� ����� ��������� (�������)
    f64 getAngleRad(const vector3d<T>& other)
    {   f64 div  = getLength()*other.getLength();
        f64 _cos = (dotProduct(other))/(div!=0?div:0.000001);
        f64 rad  = acos(_cos);
        return rad;
    }
    //------------------------------------------------------------------------
    // member variables
    //------------------------------------------------------------------------
    T X, Y, Z;
};
//----------------------------------------------------------------------------    
//! 3d triangle template class for doing collision detection and other things.
template <class T>
class triangle3d
{
public:
    //------------------------------------------------------------------------    
    //! Returns the normal of the triangle.
    //! Please note: The normal is not normalized.
    vector3d<T> getNormal() const
    {
        return (pointB - pointA).crossProduct(pointC - pointA);
    }
    //------------------------------------------------------------------------
    void set(const vector3d<T>& a, const vector3d<T>& b, const vector3d<T>& c)
    {
        pointA = a;
        pointB = b;
        pointC = c;
    }
    
    //------------------------------------------------------------------------
    //! the three points of the triangle
    vector3d<T> pointA; 
    vector3d<T> pointB; 
    vector3d<T> pointC; 
};

#endif
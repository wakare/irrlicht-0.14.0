//************************************************************************** 
//* MAX2MY3DExp.cpp	- MAX2MY3D File Exporter
//* 
//* This tool was created by Zhuck Dmitry (ZDimitor).
//* Everyone can use it as wants ( i'll be happy if it helps to someone :) ).
//*
//***************************************************************************

//------------------------------------------------------------------------------
#include "MAX2MY3DExp.h"
#include <direct.h>
//------------------------------------------------------------------------------
HINSTANCE hInstance;
int controlsInit = FALSE;
//------------------------------------------------------------------------------
static BOOL showPrompts;
static BOOL exportSelected;
//------------------------------------------------------------------------------
// Class ID. These must be unique and randomly generated!!
//------------------------------------------------------------------------------
#ifdef MY_MAX5
#define MAX2MY3D_CLASS_ID	Class_ID(0x85548e0b, 0x4a26450d) 
#elif defined MY_MAX6
#define MAX2MY3D_CLASS_ID	Class_ID(0x43a848ab, 0x531c2d87)
#elif defined MY_MAX7
#define MAX2MY3D_CLASS_ID	Class_ID(0x395431c2, 0x5db70f8b)
#else
#error Unknown 3DSMAX version!!! (specify MY_MAX5 or MY_MAX6 define directives).
#endif
//------------------------------------------------------------------------------
BOOL WINAPI DllMain(HINSTANCE hinstDLL,ULONG fdwReason,LPVOID lpvReserved) 
{
	hInstance = hinstDLL;

	// Initialize the custom controls. This should be done only once.
	if (!controlsInit) {
		controlsInit = TRUE;
		InitCustomControls(hInstance);
		InitCommonControls();
	}
	
	return (TRUE);
}
//------------------------------------------------------------------------------
__declspec( dllexport ) const TCHAR* LibDescription() 
{
	return GetString(IDS_LIBDESCRIPTION);
}
//------------------------------------------------------------------------------
/// MUST CHANGE THIS NUMBER WHEN ADD NEW CLASS 
__declspec( dllexport ) int LibNumberClasses() 
{
	return 1;
}
//------------------------------------------------------------------------------
__declspec( dllexport ) ClassDesc* LibClassDesc(int i) 
{
	switch(i) {
	case 0: return GetMAX2MY3DDesc();
	default: return 0;
	}
}
//------------------------------------------------------------------------------
__declspec( dllexport ) ULONG LibVersion() 
{
	return VERSION_3DSMAX;
}
//------------------------------------------------------------------------------
// Let the plug-in register itself for deferred loading
__declspec( dllexport ) ULONG CanAutoDefer()
{
	return 1;
}
//------------------------------------------------------------------------------
class MAX2MY3DClassDesc:public ClassDesc {
public:
	int				IsPublic() { return 1; }
	void*			Create(BOOL loading = FALSE) { return new MAX2MY3D; } 
	const TCHAR*	ClassName() { return GetString(IDS_MY3DEXP); }
	SClass_ID		SuperClassID() { return SCENE_EXPORT_CLASS_ID; } 
	Class_ID		ClassID() { return MAX2MY3D_CLASS_ID; }
	const TCHAR*	Category() { return GetString(IDS_CATEGORY); }
};
//------------------------------------------------------------------------------
char * ClassDesc::GetRsrcString(long) {return NULL;} 
//------------------------------------------------------------------------------
static MAX2MY3DClassDesc MAX2MY3DDesc;
//------------------------------------------------------------------------------
ClassDesc* GetMAX2MY3DDesc()
{
	return &MAX2MY3DDesc;
}
//------------------------------------------------------------------------------
TCHAR *GetString(int id)
{
	static TCHAR buf[256];

	if (hInstance)
		return LoadString(hInstance, id, buf, sizeof(buf)) ? buf : NULL;

	return NULL;
}
//------------------------------------------------------------------------------
MAX2MY3D::MAX2MY3D()
{
	// These are the default values that will be active when 
	// the exporter is ran the first time.
	// After the first session these options are sticky.
	bIncludeMesh = TRUE;
	bIncludeAnim = TRUE;
	bIncludeMtl =  TRUE;
	bIncludeMeshAnim =  FALSE;
	bIncludeCamLightAnim = FALSE;
	bIncludeIKJoints = FALSE;
	bIncludeNormals  =  FALSE;
	bIncludeTextureCoords = FALSE;
	bIncludeVertexColors = FALSE;
	bIncludeObjGeom = TRUE;
	bIncludeObjShape = TRUE;
	bIncludeObjCamera = TRUE;
	bIncludeObjLight = TRUE;
	bIncludeObjHelper = TRUE;
	bAlwaysSample = FALSE;
	nKeyFrameStep = 5;
	nMeshFrameStep = 5;
	nPrecision = 4;
	nStaticFrame = 0;

	bEmbeddedLightmap    = true;
	eLightmapQuality     = lq16bit;
	eLightmapCompression = lcSimple;
	bSmoothNormals  = true;
}
//------------------------------------------------------------------------------
MAX2MY3D::~MAX2MY3D()
{
}
//------------------------------------------------------------------------------
int MAX2MY3D::ExtCount()
{
	return 1;
}
//------------------------------------------------------------------------------
const TCHAR * MAX2MY3D::Ext(int n)
{
	switch(n) {
	case 0:
		// This cause a static string buffer overwrite
		// return GetString(IDS_EXTENSION1);
		return _T("MY3D");
	}
	return _T("");
}
//------------------------------------------------------------------------------
const TCHAR * MAX2MY3D::LongDesc()
{
	return GetString(IDS_LONGDESC);
}
//------------------------------------------------------------------------------
const TCHAR * MAX2MY3D::ShortDesc()
{
	return GetString(IDS_SHORTDESC);
}
//------------------------------------------------------------------------------
const TCHAR * MAX2MY3D::AuthorName() 
{
	return _T("Zhuck Dmitry (ZDimitor)");
}
//------------------------------------------------------------------------------
const TCHAR * MAX2MY3D::CopyrightMessage() 
{
	return GetString(IDS_COPYRIGHT);
}
//------------------------------------------------------------------------------
const TCHAR * MAX2MY3D::OtherMessage1() 
{
	return _T("");
}
//------------------------------------------------------------------------------
const TCHAR * MAX2MY3D::OtherMessage2() 
{
	return _T("");
}
//------------------------------------------------------------------------------
unsigned int MAX2MY3D::Version()
{
	return 100;
}
//------------------------------------------------------------------------------
static int _stdcall AboutBoxDlgProc(HWND hWnd, UINT msg, 
	WPARAM wParam, LPARAM lParam)
{
	switch (msg) {
	case WM_INITDIALOG:
		CenterWindow(hWnd, GetParent(hWnd)); 
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam)) 
		{
		case IDOK:
			EndDialog(hWnd, 1);
			break;
		}
		break;
	default:
		return FALSE;
	}
	return TRUE;
}       
//------------------------------------------------------------------------------
void MAX2MY3D::ShowAbout(HWND hWnd)
{
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, AboutBoxDlgProc, 0);
}
//------------------------------------------------------------------------------
void refreshControls(HWND hWnd,MAX2MY3D *exp)
{	if (exp)
	{
		CheckDlgButton(hWnd, IDC_RADIO_LIGHTMAP_EMBEDDED,      exp->GetEmbeddedLightmap()==true); 
		CheckDlgButton(hWnd, IDC_RADIO_LIGHTMAP_AS_STANDALONE, exp->GetEmbeddedLightmap()==false); 
		CheckDlgButton(hWnd, IDC_RADIO_LIGHTMAP_16_BIT, exp->GetLightmapQuality()==lq16bit); 
		CheckDlgButton(hWnd, IDC_RADIO_LIGHTMAP_24_BIT, exp->GetLightmapQuality()==lq24bit); 
		CheckDlgButton(hWnd, IDC_RADIO_LIGHTMAP_COMPR_NONE,   exp->GetLightmapCompression()==lcNone); 
		CheckDlgButton(hWnd, IDC_RADIO_LIGHTMAP_COMPR_SIMPLE, exp->GetLightmapCompression()==lcSimple); 
		CheckDlgButton(hWnd, IDC_RADIO_LIGHTMAP_COMPR_RLE, exp->GetLightmapCompression()==lcRLE); 		
		
		EnableWindow(GetDlgItem(hWnd, IDC_STATIC_LIGHTMAP_QUALITY), exp->GetEmbeddedLightmap());
		EnableWindow(GetDlgItem(hWnd, IDC_RADIO_LIGHTMAP_16_BIT),   exp->GetEmbeddedLightmap());
		EnableWindow(GetDlgItem(hWnd, IDC_RADIO_LIGHTMAP_24_BIT),   exp->GetEmbeddedLightmap());
		EnableWindow(GetDlgItem(hWnd, IDC_STATIC_IGHTMAP_COMPRESSION),  exp->GetEmbeddedLightmap());
		EnableWindow(GetDlgItem(hWnd, IDC_RADIO_LIGHTMAP_COMPR_NONE),   exp->GetEmbeddedLightmap());
		EnableWindow(GetDlgItem(hWnd, IDC_RADIO_LIGHTMAP_COMPR_SIMPLE), exp->GetEmbeddedLightmap());
		EnableWindow(GetDlgItem(hWnd, IDC_RADIO_LIGHTMAP_COMPR_RLE), exp->GetEmbeddedLightmap());
	}
}
//------------------------------------------------------------------------------
// Dialog proc
static int _stdcall ExportDlgProc(
	HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

	Interval animRange;
	ISpinnerControl  *spin;

	MAX2MY3D *exp = (MAX2MY3D*)GetWindowLongPtr(hWnd,GWLP_USERDATA); 
	switch (msg) 
	{
	case WM_INITDIALOG:

		exp = (MAX2MY3D*)lParam;
		SetWindowLongPtr(hWnd,GWLP_USERDATA,lParam); 
		CenterWindow(hWnd, GetParent(hWnd)); 

		refreshControls(hWnd, exp);

		break;

	case WM_COMMAND:
		switch (LOWORD(wParam)) 
		{
		case IDOK:
			EndDialog(hWnd, 1);
			break;
		case IDCANCEL:
			EndDialog(hWnd, 0);
			break;		
		case IDABOUT:
			exp->ShowAbout(hWnd);
			break;		
		case IDC_RADIO_LIGHTMAP_EMBEDDED:
			exp->SetEmbeddedLightmap(true);
			break;
		case IDC_RADIO_LIGHTMAP_AS_STANDALONE:
			exp->SetEmbeddedLightmap(false);
			break;
		case IDC_RADIO_LIGHTMAP_16_BIT:
			exp->SetLightmapQuality(lq16bit);
			break;
		case IDC_RADIO_LIGHTMAP_24_BIT:
			exp->SetLightmapQuality(lq24bit);
			break;
		case IDC_RADIO_LIGHTMAP_COMPR_NONE:
			exp->SetLightmapCompression(lcNone);
			break;
		case IDC_RADIO_LIGHTMAP_COMPR_SIMPLE:
			exp->SetLightmapCompression(lcSimple);
			break;
		case IDC_RADIO_LIGHTMAP_COMPR_RLE:
			exp->SetLightmapCompression(lcRLE);
			break;
		}
		
		refreshControls(hWnd, exp);

		break;
	default:
		return FALSE;
	}	

	return TRUE;
}       
//------------------------------------------------------------------------------
// Dummy function for progress bar
DWORD WINAPI fn(LPVOID arg)
{
	return(0);
}
//------------------------------------------------------------------------------
// Start the exporter!
// This is the real entrypoint to the exporter. After the user has selected
// the filename (and he's prompted for overwrite etc.) this method is called.
int MAX2MY3D::DoExport(const TCHAR *name,ExpInterface *ei,Interface *i, BOOL suppressPrompts, DWORD options) 
{
	// Set a global prompt display switch
	showPrompts = suppressPrompts ? FALSE : TRUE;
	exportSelected = (options & SCENE_EXPORT_SELECTED) ? TRUE : FALSE;

	// Grab the interface pointer.
	ip = i;

	// default export options
	SetIncludeMesh(TRUE);
	SetIncludeAnim(FALSE);
	SetIncludeMtl(TRUE);
	SetIncludeMeshAnim(FALSE);
	SetIncludeCamLightAnim(FALSE);
	SetIncludeIKJoints(FALSE);
	SetIncludeNormals(FALSE);
	SetIncludeTextureCoords(TRUE);
	SetIncludeObjGeom(TRUE);
	SetIncludeObjShape(FALSE);
	SetIncludeObjCamera(FALSE);
	SetIncludeObjLight(FALSE);
	SetIncludeObjHelper(FALSE);
	SetAlwaysSample(FALSE);
	SetMeshFrameStep(FALSE);
	SetKeyFrameStep(FALSE);

	SetEmbeddedLightmap    (true);
	SetLightmapQuality     (lq24bit);
	SetLightmapCompression (lcRLE);

	//----------------------------------
	firstMesh = true;	
	//----------------------------------

	// Get the options the user selected the last time
	ReadConfig();

	
	// export options dialog
    if(showPrompts) 
	{
        // Prompt the user with our dialogbox, and get all the options.
        if (!DialogBoxParam(
				hInstance, MAKEINTRESOURCE(IDD_MY3DEXPORT_DLG),
				ip->GetMAXHWnd(), ExportDlgProc, (LPARAM)this
				)
			) 
		{
            return 1;
        }
    }

	if (!bEmbeddedLightmap) _mkdir("Lightmaps");

	sprintf(szFmtStr, "%%4.%df", nPrecision);

	// Open the stream
	fname=name;
	int qq=fname.Length()-1;
	while ( (fname[qq--]!='\\') && (qq>=0) ) {};
	fname=fname.Substr(0,qq+2);
	TSTR fase;
	fase=fname+"debug.ase";
	pStream = _tfopen(fase ,_T("wt"));
	if (!pStream) {
		return 0;
	}
    
    //---------------------------------------------------    
	myExportFile = fopen(name,"wb");
    if (!myExportFile) return 0;   

    SMyFileHeader myFileHeader;
    myFileHeader.MyId=MY_ID;
    myFileHeader.Ver=MY_VER;
    // writing my file header
    myWriteToFile(&myFileHeader, sizeof(SMyFileHeader));
    //---------------------------------------------------
	
	// Startup the progress bar.
	ip->ProgressStart(GetString(IDS_PROGRESS_MSG), TRUE, fn, NULL);

	// Get a total node count by traversing the scene
	// We don't really need to do this, but it doesn't take long, and
	// it is nice to have an accurate progress bar.
	nTotalNodeCount = 0;
	nCurNode = 0;
	PreProcess(ip->GetRootNode(), nTotalNodeCount);	
	
	// First we write out a file header with global information. 
	ExportGlobalInfo();
	
	// Export list of material definitions
	ExportMaterialList();

	int numChildren = ip->GetRootNode()->NumberOfChildren();
	
	// Call our node enumerator.
	// The nodeEnum function will recurse into itself and 
	// export each object found in the scene.
	
	for (int idx=0; idx<numChildren; idx++) 
	{	if (ip->GetCancel())
			break;
		nodeEnum(ip->GetRootNode()->GetChildNode(idx), 0);
	}

	// We're done. Finish the progress bar.
	ip->ProgressEnd();

	// Close the stream
	fclose(pStream);


    //---------------------------------------------------
    u16 id=MY_FILE_END_ID;
    myWriteToFile(&id, sizeof(id));

    fclose(myExportFile);
    //---------------------------------------------------  

	// Write the current options to be used next time around.
	WriteConfig();

	return 1;
}
//------------------------------------------------------------------------------
// NOTE: Update anytime the CFG file changes
#define CFG_VERSION 0x03
//------------------------------------------------------------------------------
BOOL MAX2MY3D::ReadConfig()
{
	TSTR filename = GetCfgFilename();
	FILE* cfgStream;

	cfgStream = fopen(filename, "rb");
	if (!cfgStream)
		return FALSE;

	// First item is a file version
	int fileVersion = _getw(cfgStream);

	if (fileVersion > CFG_VERSION) {
		// Unknown version
		fclose(cfgStream);
		return FALSE;
	}

	SetIncludeMesh(fgetc(cfgStream));
	SetIncludeAnim(fgetc(cfgStream));
	SetIncludeMtl(fgetc(cfgStream));
	SetIncludeMeshAnim(fgetc(cfgStream));
	SetIncludeCamLightAnim(fgetc(cfgStream));
	SetIncludeIKJoints(fgetc(cfgStream));
	SetIncludeNormals(fgetc(cfgStream));
	SetIncludeTextureCoords(fgetc(cfgStream));
	SetIncludeObjGeom(fgetc(cfgStream));
	SetIncludeObjShape(fgetc(cfgStream));
	SetIncludeObjCamera(fgetc(cfgStream));
	SetIncludeObjLight(fgetc(cfgStream));
	SetIncludeObjHelper(fgetc(cfgStream));
	SetAlwaysSample(fgetc(cfgStream));
	SetMeshFrameStep(_getw(cfgStream));
	SetKeyFrameStep(_getw(cfgStream));

	// Added for version 0x02
	if (fileVersion > 0x01) {
		SetIncludeVertexColors(fgetc(cfgStream));
	}

	// Added for version 0x03
	if (fileVersion > 0x02) {
		SetPrecision(_getw(cfgStream));
	}

	fclose(cfgStream);

	return TRUE;
}
//------------------------------------------------------------------------------
void MAX2MY3D::PreProcess(INode* node, int& nodeCount)
{
	nodeCount++;
	
	// Add the nodes material to out material list
	// Null entries are ignored when added...
	mtlList.AddMtl(node->GetMtl());

	// For each child of this node, we recurse into ourselves 
	// and increment the counter until no more children are found.
	for (int c = 0; c < node->NumberOfChildren(); c++) {
		PreProcess(node->GetChildNode(c), nodeCount);
	}
}
//-------------------------------------------------------------------
// Dump some global animation information.
void MAX2MY3D::ExportGlobalInfo()
{
	Interval range = ip->GetAnimRange();

	struct tm *newtime;
	time_t aclock;

	time( &aclock );
	newtime = localtime(&aclock);

	TSTR today = _tasctime(newtime);	// The date string has a \n appended.
	today.remove(today.length()-1);		// Remove the \n

	// Start with a file identifier and format version
	fprintf(pStream, "%s\t%d\n", ID_FILEID, VERSION);
	
	// Text token describing the above as a comment.
	fprintf(pStream, "%s \"%s  %1.2f - %s\"\n", ID_COMMENT, GetString(IDS_VERSIONSTRING), VERSION / 100.0f, today);

	fprintf(pStream, "%s {\n", ID_SCENE);
	fprintf(pStream, "\t%s \"%s\"\n", ID_FILENAME, FixupName(ip->GetCurFileName()));
	fprintf(pStream, "\t%s %d\n", ID_FIRSTFRAME, range.Start() / GetTicksPerFrame());
	fprintf(pStream, "\t%s %d\n", ID_LASTFRAME, range.End() / GetTicksPerFrame());
	fprintf(pStream, "\t%s %d\n", ID_FRAMESPEED, GetFrameRate());
	fprintf(pStream, "\t%s %d\n", ID_TICKSPERFRAME, GetTicksPerFrame());

    //---------------------------------------------------
    SMySceneHeader sceneHeader;

    sceneHeader.MaterialCount = (u32)mtlList.Count();

    s32 MeshCount=0;
    int numChildren = ip->GetRootNode()->NumberOfChildren();
	for (int idx=0; idx<numChildren; idx++) 
	{	if (ip->GetCancel())
			break;
		calcMeshNumber(ip->GetRootNode()->GetChildNode(idx), 0, &MeshCount);
	}

    sceneHeader.MeshCount = MeshCount;
    //---------------------------------------------------
	
	Texmap* env = ip->GetEnvironmentMap();

	Control* ambLightCont;
	Control* bgColCont;
	
	if (env) 
    {
		// Output environment texture map
		DumpTexture(env, Class_ID(0,0), 0, 1.0f, 0);
	}
	else 
    {
		// Output background color
		bgColCont = ip->GetBackGroundController();
		if (bgColCont && bgColCont->IsAnimated()) 
        {
			// background color is animated.
			fprintf(pStream, "\t%s {\n", ID_ANIMBGCOLOR);
			
			DumpPoint3Keys(bgColCont, 0);
				
			fprintf(pStream, "\t}\n");
		}
		else 
        {
			// Background color is not animated
			Color bgCol = ip->GetBackGround(GetStaticFrame(), FOREVER);
			fprintf(pStream, "\t%s %s\n", ID_STATICBGCOLOR, Format(bgCol));

            //---------------------------------------------------
            sceneHeader.BackgrColor.R = (u32)bgCol.r * 255.0f;
            sceneHeader.BackgrColor.G = (u32)bgCol.g * 255.0f;
            sceneHeader.BackgrColor.B = (u32)bgCol.b * 255.0f;
            sceneHeader.BackgrColor.A = 255;
            //---------------------------------------------------
		}
	}
	
	// Output ambient light
	ambLightCont = ip->GetAmbientController();
	if (ambLightCont && ambLightCont->IsAnimated()) 
    {
		// Ambient light is animated.
		fprintf(pStream, "\t%s {\n", ID_ANIMAMBIENT);
		
		DumpPoint3Keys(ambLightCont, 0);
		
		fprintf(pStream, "\t}\n");
	}
	else 
    {
		// Ambient light is not animated
		Color ambLight = ip->GetAmbient(GetStaticFrame(), FOREVER);
		fprintf(pStream, "\t%s %s\n", ID_STATICAMBIENT, Format(ambLight));

        //---------------------------------------------------
        sceneHeader.AmbientColor.R = (u32)ambLight.r * 255.0f;
        sceneHeader.AmbientColor.G = (u32)ambLight.g * 255.0f;
        sceneHeader.AmbientColor.B = (u32)ambLight.b * 255.0f;
        sceneHeader.AmbientColor.A = 255;
        //---------------------------------------------------
	}

	fprintf(pStream,"}\n");

   
    //---------------------------------------------------
    u16 id = MY_SCENE_HEADER_ID;
    // writing my scene header id
    myWriteToFile(&id, sizeof(id));
    // writing my scene header
    myWriteToFile(&sceneHeader, sizeof(sceneHeader));
    //---------------------------------------------------

}
//-------------------------------------------------------------------
void MAX2MY3D::ExportMaterialList()
{
	if (!GetIncludeMtl()) {
		return;
	}

	fprintf(pStream, "%s {\n", ID_MATERIAL_LIST);

	int numMtls = mtlList.Count();
	fprintf(pStream, "\t%s %d\n", ID_MATERIAL_COUNT, numMtls);

    u16 id = MY_MAT_LIST_ID;
    myWriteToFile(&id, sizeof(id));

	for (int i=0; i<numMtls; i++) 
    {
		TSTR matname;
		matname = FixupName(mtlList.GetMtl(i)->GetName());        
        
        Mtl* mtl = mtlList.GetMtl(i);
        
        //---------------------------------------------------
        u16 id= MY_MAT_HEADER_ID;
        myWriteToFile(&id, sizeof(id));
        SMyMaterialHeader myMatHeader;  
        memset(myMatHeader.Name, 0, 256);
        if (sizeof(matname)<256)
            sprintf (myMatHeader.Name, "%s", matname);
        else
        {   for (int i=0 ;i<255; i++)
                myMatHeader.Name[i] = matname[i];    
            myMatHeader.Name[255]=0;
        }   
        int texNumber=0;
        CalcTextureNumber(mtl,i, -1, &texNumber);       
        
        TimeValue t = GetStaticFrame();

        myMatHeader.Index = i;
        Mtl* subMtl=0;
        if (mtl->NumSubMtls() > 0 && (subMtl = mtl->GetSubMtl(0)))  
        // if material has submaterials (we use parameters of the 1st)
        {   myMatHeader.AmbientColor  = SMyColor ( subMtl->GetAmbient(t).r*255, mtl->GetAmbient(t).g*255, subMtl->GetAmbient(t).b*255, 255);
            myMatHeader.DiffuseColor  = SMyColor ( subMtl->GetDiffuse(t).r*255, mtl->GetDiffuse(t).g*255, subMtl->GetDiffuse(t).b*255, 255);
            myMatHeader.EmissiveColor = SMyColor ( 0, 0, 0, 0);
            myMatHeader.SpecularColor = SMyColor ( subMtl->GetSpecular(t).r*255, mtl->GetSpecular(t).g*255, subMtl->GetSpecular(t).b*255, 255);
            myMatHeader.Shininess     = subMtl->GetShininess(t);   
            myMatHeader.Trasparency   = subMtl->GetXParency(t); 
        }
        else
        {   myMatHeader.AmbientColor  = SMyColor ( mtl->GetAmbient(t).r*255, mtl->GetAmbient(t).g*255, mtl->GetAmbient(t).b*255, 255);
            myMatHeader.DiffuseColor  = SMyColor ( mtl->GetDiffuse(t).r*255, mtl->GetDiffuse(t).g*255, mtl->GetDiffuse(t).b*255, 255);
            myMatHeader.EmissiveColor = SMyColor ( 0, 0, 0, 0);
            myMatHeader.SpecularColor = SMyColor ( mtl->GetSpecular(t).r*255, mtl->GetSpecular(t).g*255, mtl->GetSpecular(t).b*255, 255);
            myMatHeader.Shininess     = mtl->GetShininess(t);   
            myMatHeader.Trasparency   = mtl->GetXParency(t); 
        }

        myMatHeader.TextureCount = texNumber;

        myWriteToFile(&myMatHeader, sizeof(SMyMaterialHeader));
        //---------------------------------------------------          		
		
		DumpMaterial(mtl, i, -1, 0);

	}

	fprintf(pStream, "}\n");
}

//------------------------------------------------------------------------------
BOOL MAX2MY3D::calcMeshNumber(INode* node, int indentLevel, s32 *meshNumber) 
{	// Only export if exporting everything or it's selected
	if(!exportSelected || node->Selected()) 
	{	// The ObjectState is a 'thing' that flows down the pipeline containing
		// all information about the object. By calling EvalWorldState() we tell
		// max to eveluate the object at end of the pipeline.
		ObjectState os = node->EvalWorldState(0); 

		// The obj member of ObjectState is the actual object we will export.
		if (os.obj) 
		{	// We look at the super class ID to determine the type of the object.
			if (os.obj->SuperClassID()== GEOMOBJECT_CLASS_ID) 
                *meshNumber +=1;			
		}
	}		
	// For each child of this node, we recurse into ourselves 
	// until no more children are found.
	for (int c = 0; c < node->NumberOfChildren(); c++) 
	{	if (!calcMeshNumber(node->GetChildNode(c), indentLevel, meshNumber))
			return FALSE;
	}	
	// If thie is true here, it is the end of the group we started above.
	if (node->IsGroupHead())     
		indentLevel--;	

	return TRUE;
}

//------------------------------------------------------------------------------
// This method is the main object exporter.
// It is called once of every node in the scene. The objects are
// exported as they are encoutered.

// Before recursing into the children of a node, we will export it.
// The benefit of this is that a nodes parent is always before the
// children in the resulting file. This is desired since a child's
// transformation matrix is optionally relative to the parent.
//------------------------------------------------------------------------------
BOOL MAX2MY3D::nodeEnum(INode* node, int indentLevel) 
{
	if(exportSelected && node->Selected() == FALSE)
		return TREE_CONTINUE;

	nCurNode++;
	ip->ProgressUpdate((int)((float)nCurNode/nTotalNodeCount*100.0f)); 

	// Stop recursing if the user pressed Cancel 
	if (ip->GetCancel())
		return FALSE;
	
	TSTR indent = GetIndent(indentLevel);
	
	// If this node is a group head, all children are 
	// members of this group. The node will be a dummy node and the node name
	// is the actualy group name.
	if (node->IsGroupHead()) 
	{
		fprintf(pStream,"%s%s \"%s\" {\n", indent.data(), ID_GROUP, FixupName(node->GetName())); 
		indentLevel++;
	}
	
	// Only export if exporting everything or it's selected
	if(!exportSelected || node->Selected()) 
	{

		// The ObjectState is a 'thing' that flows down the pipeline containing
		// all information about the object. By calling EvalWorldState() we tell
		// max to eveluate the object at end of the pipeline.
		ObjectState os = node->EvalWorldState(0); 

		// The obj member of ObjectState is the actual object we will export.
		if (os.obj) 
		{	// We look at the super class ID to determine the type of the object.
			switch(os.obj->SuperClassID()) 
			{
			case GEOMOBJECT_CLASS_ID: 
				if (GetIncludeObjGeom()) ExportGeomObject(node, indentLevel); 
				break;
			case CAMERA_CLASS_ID:
				if (GetIncludeObjCamera()) ExportCameraObject(node, indentLevel); 
				break;
			case LIGHT_CLASS_ID:
				if (GetIncludeObjLight()) ExportLightObject(node, indentLevel); 
				break;
			case SHAPE_CLASS_ID:
				if (GetIncludeObjShape()) ExportShapeObject(node, indentLevel); 
				break;
			case HELPER_CLASS_ID:
				if (GetIncludeObjHelper()) ExportHelperObject(node, indentLevel); 
				break;
			}
		}
	}	
	
	// For each child of this node, we recurse into ourselves 
	// until no more children are found.
	for (int c = 0; c < node->NumberOfChildren(); c++) 
	{
		if (!nodeEnum(node->GetChildNode(c), indentLevel))
			return FALSE;
	}
	
	// If thie is true here, it is the end of the group we started above.
	if (node->IsGroupHead()) {
		fprintf(pStream,"%s}\n", indent.data());
		indentLevel--;
	}

	return TRUE;
}
//------------------------------------------------------------------------------
void MAX2MY3D::WriteConfig()
{
	TSTR filename = GetCfgFilename();
	FILE* cfgStream;

	cfgStream = fopen(filename, "wb");
	if (!cfgStream)
		return;

	// Write CFG version
	_putw(CFG_VERSION,				cfgStream);

	fputc(GetIncludeMesh(),			cfgStream);
	fputc(GetIncludeAnim(),			cfgStream);
	fputc(GetIncludeMtl(),			cfgStream);
	fputc(GetIncludeMeshAnim(),		cfgStream);
	fputc(GetIncludeCamLightAnim(),	cfgStream);
	fputc(GetIncludeIKJoints(),		cfgStream);
	fputc(GetIncludeNormals(),		cfgStream);
	fputc(GetIncludeTextureCoords(),	cfgStream);
	fputc(GetIncludeObjGeom(),		cfgStream);
	fputc(GetIncludeObjShape(),		cfgStream);
	fputc(GetIncludeObjCamera(),	cfgStream);
	fputc(GetIncludeObjLight(),		cfgStream);
	fputc(GetIncludeObjHelper(),	cfgStream);
	fputc(GetAlwaysSample(),		cfgStream);
	_putw(GetMeshFrameStep(),		cfgStream);
	_putw(GetKeyFrameStep(),		cfgStream);
	fputc(GetIncludeVertexColors(),	cfgStream);
	_putw(GetPrecision(),			cfgStream);

	fclose(cfgStream);
}
//------------------------------------------------------------------------------
BOOL MAX2MY3D::SupportsOptions(int ext, DWORD options) 
{
	assert(ext == 0);	// We only support one extension
	return(options == SCENE_EXPORT_SELECTED) ? TRUE : FALSE;
}
//------------------------------------------------------------------------------
// Configuration.
// To make all options "sticky" across sessions, the options are read and
// written to a configuration file every time the exporter is executed.
//------------------------------------------------------------------------------
TSTR MAX2MY3D::GetCfgFilename()
{
	TSTR filename;
	
	filename += ip->GetDir(APP_PLUGCFG_DIR);
	filename += "\\";
	filename += CFGFILENAME;

	return filename;
}
//------------------------------------------------------------------------------
BOOL MtlKeeper::AddMtl(Mtl* mtl)
{
	if (!mtl) {
		return FALSE;
	}

	int numMtls = mtlTab.Count();
	for (int i=0; i<numMtls; i++) {
		if (mtlTab[i] == mtl) {
			return FALSE;
		}
	}
	mtlTab.Append(1, &mtl, 25);

	return TRUE;
}
//------------------------------------------------------------------------------
int MtlKeeper::GetMtlID(Mtl* mtl)
{
	int numMtls = mtlTab.Count();
	for (int i=0; i<numMtls; i++) {
		if (mtlTab[i] == mtl) {
			return i;
		}
	}
	return -1;
}
//------------------------------------------------------------------------------
int MtlKeeper::Count()
{
	return mtlTab.Count();
}
//------------------------------------------------------------------------------
Mtl* MtlKeeper::GetMtl(int id)
{
	return mtlTab[id];
}
//------------------------------------------------------------------------------
void MAX2MY3D::myWriteToFile(void *buf, int size)
{
    fwrite(buf,size,1,myExportFile);
}
//------------------------------------------------------------------------------
